#include "quakedef.h"

qboolean GLVID_Init(rendererstate_t *info, unsigned char *palette)
{
	return false;
}

void GLVID_DeInit()
{
}

void GLVID_ShiftPalette(unsigned char *p)
{
}

void GLVID_SetPalette(unsigned char *palette)
{
}

void Sys_SendKeyEvents(void)
{
}

void GLD_BeginDirectRect(int x, int y, qbyte *pbitmap, int width, int height)
{
}

void GLD_EndDirectRect(int x, int y, int width, int height)
{
}

void GLVID_SwapBuffers(void)
{
}

void GLVID_SetCaption(char *text)
{
}

/*** Input ***/

void IN_ReInit(void)
{
}

void IN_Init(void)
{
}

void IN_Shutdown(void)
{
}

void IN_Commands(void)
{
}

void IN_Move(float *movements, int pnum)
{
}

