/*
	replaced by zqtp.c (read: teamplay.c ported from zquake instead, with later fuhquake+ezquake additions, the ravages of time can be merciless)
*/

